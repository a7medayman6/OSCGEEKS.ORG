
<?php $__env->startSection('content'); ?>
<style>
    td{
        border-bottom: 1px solid #09c;
    }
</style>
    <div class="row">
        <div class="col-12">
            <table class="table table-striped table-hover">
                <thead>
                  <tr>
                    <th scope="col">id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">College</th>
                    <th scope="col">Year</th>
                    <th scope="col">ComA</th>
                    <th scope="col">DateComA</th>
                    <th scope="col">TimeComA</th>
                    
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($member->id); ?></td>
                            <td><?php echo e($member->name); ?></td>
                            <td><?php echo e($member->email); ?></td>
                            <td><?php echo e($member->phone); ?></td>
                            <td><?php echo e($member->college); ?></td>
                            <td><?php echo e($member->studentYear); ?></td>
                            <td><?php echo e($member->committee_A); ?></td>
                            <td><?php echo e($member->dateCommittee_A); ?></td>
                            <td><?php echo e($member->timeCommittee_A); ?></td>
                            <td><?php echo e($member->committee_B); ?></td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\my work\Laravel projects\OSC-Website-main\osc\resources\views/Committees/EventMembers.blade.php ENDPATH**/ ?>