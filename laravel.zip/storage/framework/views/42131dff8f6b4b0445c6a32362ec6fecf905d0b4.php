<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, minimum-scale=1">
          

        <title><?php echo $__env->yieldContent('title'); ?></title>
        <link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
        <link href='https://fonts.googleapis.com/css?family=Sofia' rel='stylesheet'>	
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('css/style2.css')); ?>">
        <link rel="stylesheet" media="handheld, only screen and (max-device-width: 990px)" href="<?php echo e(asset('css/Home_mobile.css')); ?>" />
        
        <?php echo $__env->yieldContent('cssFile'); ?>
        <link rel="stylesheet"  media="screen" href="<?php echo e(asset('css/Home.css')); ?>">
        <link rel="icon" href="<?php echo e(asset('img/logo22.png')); ?>"> 
        <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>"/>
        <link href="<?php echo e(asset('style/all.css')); ?>" rel="stylesheet">
        <style>
          
</style>
    </head>
    <body>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light  transparent  top_navbar ">
            <div class="navbar-brand navbar_left_part"  >
                <img src="<?php echo e(asset('img/logo osc@2x.png')); ?>" alt="OSC Logo" id="logo_at_Navbar"> 
                <img src="<?php echo e(asset('img/Open Source Community.png')); ?>" alt="Open Source Community" id="OSC_img">

            </div>
              <div class="toggle-navbar-image"></div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon_ "> 
                <img src="<?php echo e(asset('img/Rectangle 47.png')); ?>" class="nav_bar1">
                <img src="<?php echo e(asset('img/Rectangle 47.png')); ?>" class="nav_bar2">
                <img src="<?php echo e(asset('img/Rectangle 47.png')); ?>" class="nav_bar3">
              </span>
            </button>
          
            <div class="collapse navbar-collapse " id="navbarSupportedContent">
              <ul class="navbar-nav ml-auto  navbar_right_part">
                <li class="nav-item active">
                  <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    committees 
                    <i class="arrow down"></i>
                  </a>
                  <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <div class="dropdown_menu_part float-left">
                      <div class="dropdown_left_part float-left">
                        <a class="dropdown-item" href="<?php echo e(route('art.view')); ?>"><img src="<?php echo e(asset('img/paint-palette.png')); ?>" alt="Art"> Art & Desgin</a>
                        <a class="dropdown-item" href="<?php echo e(route('linux.view')); ?>"> <img src="<?php echo e(asset('img/linux.png')); ?>" alt="Linux"> Linux</a> 
                        <a class="dropdown-item" href="<?php echo e(route('web.view')); ?>"><img src="<?php echo e(asset('img/web-browser.png')); ?>" alt="Web"> Web</a>
                        <a class="dropdown-item" href="<?php echo e(route('hr.view')); ?>"><img src="<?php echo e(asset('img/Human Resource-Job Search-Magnifying Glass-Paper-Search.png')); ?>" alt="HR"> HR</a> 
                        <a class="dropdown-item" href="<?php echo e(route('pr.view')); ?>"><img src="<?php echo e(asset('img/public-relation.png')); ?>" alt="PR"> PR</a>
                        <a class="dropdown-item" href="<?php echo e(route('lr.view')); ?>"><img src="<?php echo e(asset('img/order.png')); ?>" alt="LR"> LR</a>
                      </div>
                      <div class="dropdown_right_part float-right">
                         <a class="dropdown-item" href="<?php echo e(route('blender.view')); ?>"><img src="<?php echo e(asset('img/Blender.png')); ?>" alt="Blender"> Blender</a>
                         <a class="dropdown-item" href="<?php echo e(route('game.view')); ?>"><img src="<?php echo e(asset('img/game-controller.png')); ?>" alt="Game"> Game</a> 
                         <a class="dropdown-item" href="<?php echo e(route('projects.view')); ?>"><img src="<?php echo e(asset('img/project-management.png')); ?>" alt="Projects"> Projects</a>
                         <a class="dropdown-item" href="<?php echo e(route('eh.view')); ?>"><img src="<?php echo e(asset('img/english.png')); ?>" alt="English"> English Heros</a>
                         <a class="dropdown-item" href="<?php echo e(route('ccc.view')); ?>"><img src="<?php echo e(asset('img/video-camera.png')); ?>" alt="CCC"> CCC</a>
                      </div>
                    </div>
                </div>
                </li>
                <li class="nav-item">
                  <a class="nav-link " href="<?php echo e(route('aboutUs.view')); ?>">About</a>
                </li>
              </ul>
            
            </div>
          </nav>
<!--  Navbar -->

<!-- Background -->
          <div class="Home_background">
            <img src="<?php echo e(asset('img/BG 1.png')); ?>" id="img1">
            <img src="<?php echo e(asset('img/Path 140.png')); ?>" id="img3">
            <img src="<?php echo e(asset('img/Ellipse 8.png')); ?>" id="img4">
            <img src="<?php echo e(asset('img/Ellipse 7.png')); ?>" id="img5">
            <img src="<?php echo e(asset('img/Ellipse 9.png')); ?>" id="img6">
            <img src="<?php echo e(asset('img/Ellipse 10.png')); ?>" id="img7">
          </div>
<!-- Background -->
<?php echo $__env->yieldContent('content'); ?>







 




<div class="contact" >
			<div class="container">
				<div class="row" data-aos="fade-up" data-aos-duration="3000">
					<div class="part-2 col-lg-7 col-md-7 col-sm-12 col-xs-12">
						<img src="<?php echo e(asset('img/img.png')); ?>" alt="contact-img" style="width: 100%;">
					</div>
					<div class="part-1 col-lg-5 col-md-5 col-sm-12 col-xs-12">
						<h3 class="hhh">Contact Us</h3>
						<form>
							<input  class="form-control" type="text" placeholder="first name">
							<input  class="form-control" typt="text" placeholder="last name">
							<input  class="form-control" type="text" placeholder="E-mail">
							<textarea placeholder="Your Message..." style="height:200px"></textarea>
							</form>
							<button type="submit" class="btn btn-primary btn-md">Send</button>
					</div>
					
				</div>
			</div>
    </div>
    <div class="fotter">
      <div class="left-side">
          <img src="<?php echo e(asset('img/logo22.png')); ?>"  alt="OSC" >
          <h1 class="fotTitle">Open Source Community</h1>
          <p class="fotDescription">FCIS Student Activity</p>
          <p class="cpy">Copyright OSC &copy 2020</p>
      </div>          
      <div class="right-side">
          <h4>Follow Up Social Media</h4>
          
          <ul>
            <li> <a href="https://twitter.com/oscgeeks?fbclid=IwAR07erATlCzqcfWuq0pRcZp4mHVoQsbHN8Kq2kPSnYYZoeVJkfc5nM0g_AQ"><i class="fab fa-twitter fa-1x"></i></a></li>
              <li><a href="https://www.facebook.com/oscgeeks"><i class="fab fa-facebook-f fa-1x"></i></a></li>
              
              <li><a href="https://www.instagram.com/oscgeeks/?fbclid=IwAR37GPRkG1lJ-93z6CAO4NVJ58wAud9WscYLthcvMa53-TQqrYYlJmqGcmE"><i class="fab fa-instagram fa-1x"></i></a></li>
              <li><a href="https://www.youtube.com/channel/UCvgdICw5bI7KKTRa5ohksWg"><i class="fab fa-youtube fa-1x"></i></a></li>
          </ul>
      </div>
    </div>
        <script src="http://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script type="text/javascript" src="<?php echo e(asset('js/Home.js')); ?>"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  AOS.init();
</script>
    </body>
</html>
<?php /**PATH F:\my work\Laravel projects\OSC-Website-main\osc\resources\views/layout/master.blade.php ENDPATH**/ ?>