
<?php $__env->startSection('title'); ?>
    Open Source Community | Game Commitee
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('cssFile'); ?>
<link rel ="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="topTopic">
<img class="c_logo" src="<?php echo e(asset('committees_img/Game.svg')); ?>" alt="Icon Pic">
    	<h1 class="monospace"> Game Committee</h1>
    	 <div>
          <p class="description">Is the committee which developing games using Godot Open Source Game Engine 
              with using C# Or GDScript To make 2D and 3D games.</p>
          
      </div>
  	</div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\my work\Laravel projects\OSC-Website-main\osc\resources\views/Committees/game.blade.php ENDPATH**/ ?>