
<?php $__env->startSection('title'); ?>
    Open Source Community | PR Commitee
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('cssFile'); ?>
<link rel ="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="topTopic">
<img class="c_logo" src="<?php echo e(asset('committees_img/PR.svg')); ?>" alt="Icon Pic">
    	<h1 class="monospace"> PR Committee</h1>
    	 <div>
          <p class="description">We are the voice and the image of OSC. Our mission is to let the people know who we are and what we do by teaching our members Soft skills  and we are responsible for the connection between the college and OSC. Also we concur with sponsers to support our work.</p>
          
      </div>
  	</div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\my work\Laravel projects\OSC-Website-main\osc\resources\views/Committees/pr.blade.php ENDPATH**/ ?>