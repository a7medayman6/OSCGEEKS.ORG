
<?php $__env->startSection('content'); ?>
   <h1> Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\my work\Laravel projects\OSC-Website-main\osc\resources\views/admin.blade.php ENDPATH**/ ?>