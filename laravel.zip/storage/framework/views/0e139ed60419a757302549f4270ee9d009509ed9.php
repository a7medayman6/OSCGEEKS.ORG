
<?php $__env->startSection('title'); ?>
    Open Source Community | HR Commitee
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('cssFile'); ?>
<link rel ="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="topTopic">
<img class="c_logo" src="<?php echo e(asset('committees_img/HR.svg')); ?>" alt="Icon Pic">
    	<h1 class="monospace"> HR Committee</h1>
    	 <div>
          <p class="description">Our main responsibility is interviewing people aspiring to be in our community and making sure they are fit for their roles.
<br> A HR member joins each committee to make sure each that everything is going according to plan
Teaching new comers how to do an interview, have responsibility and be excellent decision makers.</p>
          
      </div>
  	</div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\my work\Laravel projects\OSC-Website-main\osc\resources\views/Committees/hr.blade.php ENDPATH**/ ?>