
<?php $__env->startSection('title'); ?>
    Open Source Community | Art Commitee
	<?php $__env->stopSection(); ?>
<?php $__env->startSection('cssFile'); ?>
<link rel ="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="topTopic">
  		<img class="c_logo" src="<?php echo e(asset('committees_img/Art.svg')); ?>" alt="Icon Pic">
    	<h1 class="monospace"> Art Committee</h1>
    	<div>
      		<p class="description"><strong>Let your imagination lead your way</strong>
				We are the designers of OSC, as we design the Posters, Banners, T-shirt design, IDs, and Facebook Posts, by using open source tools like <strong>Gimp</strong> & <strong>Inkscape</strong>.</p>
      		
    	</div>
  	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\my work\Laravel projects\OSC-Website-main\osc\resources\views/Committees/art.blade.php ENDPATH**/ ?>