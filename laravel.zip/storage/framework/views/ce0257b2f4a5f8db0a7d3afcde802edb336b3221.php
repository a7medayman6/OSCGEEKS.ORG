
<?php $__env->startSection('title'); ?>
    Open Source Community | Blender Commitee
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('cssFile'); ?>
<link rel ="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="topTopic">
<img class="c_logo" src="<?php echo e(asset('committees_img/Blender.svg')); ?>" alt="Icon Pic">
        <h1 class="monospace">Blender Committee</h1>
        <div>
            <p class="description">we use Blender (open-source 3D computer graphics software) to make artworks.<br>
We are looking forward to developing our skills on blender and create more challenging artworks.</p>
           
        </div>
  	</div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\my work\Laravel projects\OSC-Website-main\osc\resources\views/Committees/blender.blade.php ENDPATH**/ ?>