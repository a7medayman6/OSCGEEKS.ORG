@extends('layout.back')
@section('content')
   <h1> Dashboard</h1>
@endsection
