@extends('layout.master')
@section('title')
    Open Source Community | PR Commitee
    @endsection
    @section('cssFile')
<link rel ="stylesheet" href="{{asset('css/style.css')}}">
@endsection
@section('content')
<div class="topTopic">
<img class="c_logo" src="{{asset('committees_img/PR.svg')}}" alt="Icon Pic">
    	<h1 class="monospace"> PR Committee</h1>
    	 <div>
          <p class="description">We are the voice and the image of OSC. Our mission is to let the people know who we are and what we do by teaching our members Soft skills  and we are responsible for the connection between the college and OSC. Also we concur with sponsers to support our work.</p>
          
      </div>
  	</div>
      @endsection